
    <?php include 'headline/header.php'; ?>

    <div class="hero-wrap" style="background-image: url('images/bg_5.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center" data-scrollax-parent="true">
          <div class="col-md-7 ftco-animate text-center" data-scrollax=" properties: { translateY: '70%' }">
             <p class="breadcrumbs" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><span class="mr-2"><a href="index.php">Home</a></span> <span>Causes</span></p>
            <h1 class="mb-3 bread" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Causes</h1>
          </div>
        </div>
      </div>
    </div>

    
    <section class="ftco-section">
      <div class="container">
      	<div class="row">
      		<div class="col-md-4 ftco-animate">
      			<div class="cause-entry">
    					<a href="#" class="img" style="background-image: url(images/cause-1.jpg);"></a>
    					<div class="text p-3 p-md-4">
    						<h3><a href="#">Get a flu shot</a></h3>
    						<p>Getting a flu vaccine can help keep your family and your commuinty healthy this season. Getting a flu shot is an easy and inexpensive way to help minimizing flu cases which will reduce stress on already overburdened healthcare systems.</p>
    						<span class="donation-time mb-3 d-block">Last donation 1w ago</span>
                <div class="progress custom-progress-success">
                  <div class="progress-bar bg-primary" role="progressbar" style="width: 28%" aria-valuenow="28" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
                <span class="fund-raised d-block">Rs 12,000 raised of Rs 30,000</span>
    					</div>
    				</div>
      		</div>
      		<div class="col-md-4 ftco-animate">
      			<div class="cause-entry">
    					<a href="#" class="img" style="background-image: url(images/cause-2.jpg);"></a>
    					<div class="text p-3 p-md-4">
    						<h3><a href="#">Help your local food pantry.</a></h3>
    						<p>Today, there are an estimated 10 million Poor families struggling with hunger in India. Contact your local food pantry or give to our partner No Kid Hungry. Your support will help them provide food items for families in need</p>
    						<span class="donation-time mb-3 d-block">Last donation 1w ago</span>
                <div class="progress custom-progress-success">
                  <div class="progress-bar bg-primary" role="progressbar" style="width: 28%" aria-valuenow="28" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
                <span class="fund-raised d-block">Rs 12,000 raised of Rs 30,000</span>
    					</div>
    				</div>
      		</div>
      		<div class="col-md-4 ftco-animate">
      			<div class="cause-entry">
    					<a href="#" class="img" style="background-image: url(images/cause-3.jpg);"></a>
    					<div class="text p-3 p-md-4">
    						<h3><a href="#">Give blood if you are able.</a></h3>
    						<p>Red Cross and other organizations are in dire need of blood supply and have safe, healthy ways for you to donate.</p>
    						<span class="donation-time mb-3 d-block">Last donation 1w ago</span>
                <div class="progress custom-progress-success">
                  <div class="progress-bar bg-primary" role="progressbar" style="width: 28%" aria-valuenow="28" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
                <span class="fund-raised d-block">Rs12,000 raised of Rs 30,000</span>
    					</div>
    				</div>
      		</div>
      		<div class="col-md-4 ftco-animate">
      			<div class="cause-entry">
    					<a href="#" class="img" style="background-image: url(images/cause-4.jpg);"></a>
    					<div class="text p-3 p-md-4">
    						<h3><a href="#">Check on neighbors and family members</a></h3>
    						<p>Especially those who live alone, are elderly, have health or mobility issues or are caring for children. Schedule time to remotely connect with these individuals regularly to let them know they are not alone.</p>
    						<span class="donation-time mb-3 d-block">Last donation 1w ago</span>
                <div class="progress custom-progress-success">
                  <div class="progress-bar bg-primary" role="progressbar" style="width: 28%" aria-valuenow="28" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
                <span class="fund-raised d-block">Rs 12,000 raised of Rs 30,000</span>
    					</div>
    				</div>
      		</div>
      		<div class="col-md-4 ftco-animate">
      			<div class="cause-entry">
    					<a href="#" class="img" style="background-image: url(images/cause-5.jpg);"></a>
    					<div class="text p-3 p-md-4">
    						<h3><a href="#">Support local businesses, schools and child care centers</a></h3>
    						<p>When possible, purchase gift cards to local shops businesses online that you can use once storefronts reopen, and uplift those who are trying to keep afloat. Due to COVID-19, many child care centers across the country have been forced to shut down. </p>
    						<span class="donation-time mb-3 d-block">Last donation 1w ago</span>
                <div class="progress custom-progress-success">
                  <div class="progress-bar bg-primary" role="progressbar" style="width: 28%" aria-valuenow="28" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
                <span class="fund-raised d-block">RS 12,000 raised of Rs 30,000</span>
    					</div>
    				</div>
      		</div>
      		<div class="col-md-4 ftco-animate">
      			<div class="cause-entry">
    					<a href="#" class="img" style="background-image: url(images/cause-6.jpg);"></a>
    					<div class="text p-3 p-md-4">
    						<h3><a href="#">Take care of yourself and others</a></h3>
    						<p> Practice patience, kindness and mindfulness. Encourage others to do the same!.</p>
    						<span class="donation-time mb-3 d-block">Last donation 1w ago</span>
                <div class="progress custom-progress-success">
                  <div class="progress-bar bg-primary" role="progressbar" style="width: 28%" aria-valuenow="28" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
                <span class="fund-raised d-block">Rs 12,000 raised of Rs 30,000</span>
    					</div>
    				</div>
      		</div>
        </div>
        </div>
      </div>
    </section>

    <section class="ftco-section-3 img" style="background-image: url(images/bg_3.jpg);">
    	<div class="overlay"></div>
    	<div class="container">
    		<div class="row d-md-flex">
    		<div class="col-md-6 d-flex ftco-animate">
    			<div class="img img-2 align-self-stretch" style="background-image: url(images/bg_4.jpg);"></div>
    		</div>
    		<div class="col-md-6 volunteer pl-md-5 ftco-animate">
    			<h3 class="mb-3">Be a volunteer</h3>
    			<form action="#" class="volunter-form">
            <div class="form-group">
              <input type="text" class="form-control" placeholder="Your Name">
            </div>
            <div class="form-group">
              <input type="text" class="form-control" placeholder="Your Email">
            </div>
            <div class="form-group">
              <textarea name="" id="" cols="30" rows="3" class="form-control" placeholder="Message"></textarea>
            </div>
            <div class="form-group">
              <input type="submit" value="Send Message" class="btn btn-white py-3 px-5">
            </div>
          </form>
    		</div>    			
    		</div>
    	</div>
    </section>
		

    <?php include 'headline/footer.php'; ?>
