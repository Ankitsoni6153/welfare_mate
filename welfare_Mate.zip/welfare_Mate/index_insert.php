<?php
$con=mysqli_connect('localhost','root','','welfare');

function str_openssl_enc($str, $iv){
	$key = 'mySecureKey'; 
	$cipher = "AES-256-CTR"; 
	$options = 0;
	$str = openssl_encrypt($str, $cipher, $key, $options, $iv);
	return $str;
}

$s_no = $_REQUEST['s_no'];
$name = $_REQUEST['name'];

$email_id = $_REQUEST['email_id'];

$message = $_REQUEST['message'];

$ivlen = openssl_cipher_iv_length("AES-256-CTR");
$iv = openssl_random_pseudo_bytes($ivlen);

$enc_name = str_openssl_enc($name, $iv);
$enc_email = str_openssl_enc($email_id, $iv);
$enc_message = str_openssl_enc($message, $iv);

$stmt = $con->prepare("INSERT INTO queryc (s_no, name, email_id, message, iv) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("issss", $s_no, $enc_name, $enc_email, $enc_message, bin2hex($iv));

if ($stmt->execute()) {
    header("Location: index.php");
    echo "Data has been inserted!";
} else {
    echo "Error: " . $con->error;
}

mysqli_close($con);
?>
