<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>
<?php include 'dash/user-header.php'; ?>

           <style>
            body {
			background-color: #f5f5f5;
			font-family: 'Helvetica Neue', sans-serif;
		}
		.container {
			max-width: 800px;
			margin: 0 auto;
			padding: 50px;
			background-color: #fff;
			border-radius: 10px;
			box-shadow: 0px 5px 20px rgba(0,0,0,0.2);
		}
		h1 {
			
			font-size: 36px;
			color: #333;
			margin-bottom: 5px;
		}
		.text {
			font-size: 24px;
			color: #333;
			margin-bottom: 30px;
			text-align: center;
		}
		.signature {
			float: right;
			margin-top: 30px;
			margin-right: 30px;
			width: 150px;
			height: 50px;
		}
		.certlo{
			height: 130px;
			width: 90px;
		}
           </style>
            <div class="container">
		<h1> <img src="certlogo.png" class="certlo" alt=""> Certificate of Appreciation</h1>
		<p class="text">This certificate is awarded to <strong><?php echo $_SESSION['name']; ?></strong>
         for his outstanding contribution to our welfare organization.</p>
		<img src="sign.jpg" alt="signature" class="signature">
		<p class="text">Signed by <br>Happy Welfare</p>
		
		<p style="text-align: right;">President of Welfare Organization</p>
	</div>
 </div>

        <?php include 'dash/footer.php'; ?>
      

<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>