<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {
    include 'dash/header.php'; 
?>

<div class="row">
    <div class="col">
        <div class="card mb-3">
            <div class="card-header">
                <div class="caption uppercase">
                    <i class="ti-briefcase"></i>People have some query (Some more important data)
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover init-datatable" id="">
                        <thead class="thead-light">
                            <tr>
                                <th>S.No:</th>
                                <th>Name:</th>
                                <th>Email Id:</th>
                                <th>Message</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $conn = new mysqli('localhost', 'root', '', 'welfare');
                            if ($conn->connect_error) {
                                die("Unable to connect to database: " . $conn->connect_error);
                            } else {
                                $query = mysqli_query($conn, "SELECT * FROM queryc");
                                if (mysqli_num_rows($query) > 0) {
                                    while ($rowdata = mysqli_fetch_assoc($query)) {
                                        $s_no = $rowdata['s_no'];
                                        $enc_name = $rowdata['name'];
                                        $enc_email = $rowdata['email_id'];
                                        $enc_message = $rowdata['message'];
                                        $iv = hex2bin($rowdata['iv']);
                                        
                                        // decrypt the sensitive data
                                        $key = 'mySecureKey'; // change the key to a more secure value
                                        $cipher = "AES-256-CTR"; // change the cipher to a more secure value
                                        $options = 0;
                                        $name = openssl_decrypt($enc_name, $cipher, $key, $options, $iv);
                                        $email_id = openssl_decrypt($enc_email, $cipher, $key, $options, $iv);
                                        $message = openssl_decrypt($enc_message, $cipher, $key, $options, $iv);

                                        echo "<tr>";
                                        echo "<td>{$s_no}</td>";
                                        echo "<td>{$name}</td>";
                                        echo "<td>{$email_id}</td>";
                                        echo "<td>{$message}</td>";
                                        echo "<td><a href='delete.php?del={$s_no}'>Delete</a></td>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='5'>No records found.</td></tr>";
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
    include 'dash/footer.php'; 
} else {
    header("Location: index.php");
    exit();
}
?>
