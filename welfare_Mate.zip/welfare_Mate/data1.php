

<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>
<?php include 'dash/header.php'; ?>

            <!-- EOF Breadcrumb -->

            <!-- BOF MAIN-BODY -->
            
           
            
            <!-- EOF Datatable Addrows -->
            <!-- BOF Datatable Complex Headers -->
            <div class="row">
                <div class="col">
                    <div class="card mb-3">
                        <div class="card-header">
                            <div class="caption uppercase">
                                <i class="ti-briefcase"></i> People Wants to contact with you (Some more important data)
                            </div>
                            
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover init-datatable" id="">
                                    <thead class="thead-light">
                                       
                                        <tr>
                                        <th>S.No:</th>
                          <th>Name:</th>
                          <th>Email Id:</th>
                          <th>Subject:</th>
                          <th>Message:</th> 
                          <th>Action:</th>
                                        </tr>
                                    </thead>



                                    <tbody>
                                        
           <?php
      $conn=new mysqli('localhost','root','','welfare',);
      if($conn->connect_error)
      {
          echo"unable to connect";
          echo 'br';
      }
      else{
         
          $query=mysqli_query($conn,"SELECT * FROM contact");
          if(mysqli_num_rows($query)>0)
          {
              while($rowdata=mysqli_fetch_assoc($query))
              {
               echo" <tr>";
               echo "<td>{$rowdata['s_no']}</td>";
               echo "<td>{$rowdata['name']}</td>";
               echo "<td>{$rowdata['email_id']}</td>";
               echo "<td>{$rowdata['subject']}</td>";
              
               echo "<td>{$rowdata['message']}</td>";
             
             echo "<td>  <a href='contact_delete.php?del={$rowdata['s_no']}'>Delete</a> </td>";
               echo "</tr>";
      
              }
          }
      }
      ?>
           
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- EOF Datatable Complex Headers -->
            <!-- BOF Datatable Row Selection -->
            
            <!-- EOF Datatable Row Selection -->
            <!-- BOF Datatable Events -->
            
            <!-- EOF Datatable Events -->
            <!-- BOF Datatable Show/Hide Columns -->
            
            <!-- EOF MAIN-BODY -->

        </div>
        <!-- EOF MAIN -->

        <!-- BOF FOOTER -->
        <?php include 'dash/footer.php'; ?>
      

<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>