<?php include 'headline/header.php'; ?>

    
    <div class="hero-wrap" style="background-image: url('images/bg_7.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center" data-scrollax-parent="true">
          <div class="col-md-7 ftco-animate text-center" data-scrollax=" properties: { translateY: '70%' }">
             <p class="breadcrumbs" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><span class="mr-2"><a href="index.php">Home</a></span> <span>About</span></p>
            <h1 class="mb-3 bread" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">About Us</h1>
          </div>
        </div>
      </div>
    </div>

    
    <section class="ftco-section">
    	<div class="container">
    		<div class="row d-flex">
    			<div class="col-md-6 d-flex ftco-animate">
    				<div class="img img-about align-self-stretch" style="background-image: url(images/bg_9.jpg); width: 100%;"></div>
    			</div>
    			<div class="col-md-6 pl-md-5 ftco-animate">
    				<h2 class="mb-4">Welcome to Happy Health Help Stablished Since 2023</h2>
    				<p>I am very happy to introduce “Happy Health Help Foundation”, Indian non-profit based Organization. On behalf of Happy Health Help Foundation, I welcome you all.

With such aims and objectives, it was established having strong message for the various purpose, to do something for the growth of our Country in various segments for the development of India.

Happy Health Help Foundationwith a motive for the development of poor children’s, Farmers, Women empowerment, Old age people, helpful persons, etc. in the segment of Education, Health,etc.</p>
    				<p>In case you intend to donate to multiple NGOs in India, who are also our partners, you can write to us at info@HappyHealthHelp.org.We assure to take full responsibility to rationally distribute the donation, for the projects and campaigns who are in most need. </p>
    			</div>
    		</div>
    	</div>
    </section>

    <section class="ftco-counter ftco-intro ftco-intro-2" id="section-counter">
    	<div class="container">
    		<div class="row no-gutters">
    			
          <div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
            <div class="block-18 color-2 align-items-stretch">
              <div class="text">
              	<h3 class="mb-4">Donate Money</h3>
              	<p>Your contribution can make a meaningful difference in someone's life. Please consider donating to our welfare account today.
                Together, we can create positive change in our community. Your donation to our welfare account will help us support those in need.
                Every donation counts towards creating a better world. Please donate to our welfare account and help us make a real difference in people's lives.
                
                </p>
              	<p><a href="#" class="btn btn-white px-3 py-2 mt-2">Donate Now</a></p>
              </div>
            </div>
          </div>
         
    		</div>
    	</div>
    </section>

    
		

    <?php include 'headline/footer.php'; ?>
