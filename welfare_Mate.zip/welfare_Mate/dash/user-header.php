<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
   <title>Dashboard</title>
   <link rel="stylesheet" href="assets/css/siqtheme.css">
</head>

<body class="theme-dark">
    <div class="grid-wrapper sidebar-bg bg1">

          <div class="header">
            <div class="header-bar">
                <div class="brand">
                    <a href="index.php" class="logo">User<span class="text-carolina"><?php echo $_SESSION['name']; ?> </span></a>
                    <a href="index.php" class="logo-sm text-carolina" style="display: none;">siQ</a>
                </div>
                <div class="btn-toggle">
                    <a href="#" class="slide-sidebar-btn" style="display: none;"><i class="ti-menu"></i></a>
                </div>
                <div class="navigation d-flex">
                    <div class="navbar-menu d-flex">
                      <div class="menu-item">
                            <a href="#" class="btn right-sidebar-toggle"><i class="ti-user"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <div id="sidebar" class="sidebar">
            <div class="sidebar-content">
                <!-- sidebar-menu  -->
                <div class="sidebar-menu">
                    <ul>
                     <li class="header-menu">
                          Admin Panel
                        </li>
                        <li class="">
                            <a href="userdashboard.php">
                                <i class="ti-dashboard"></i>
                                <span class="menu-text">Dashboard</span>
                            </a>
                        </li>
                        <li class=" ">
                        <a href="chat_project/index.php">
                                <i class="ti-layout-grid2"></i>
                                <span class="menu-text">Message To admin</span>
                            </a>
                            
                        </li>
                        <li class=" ">
                            <a href="donation/index.php">
                                <i class="ti-layout-grid2"></i>
                                <span class="menu-text">Donation</span>
                            </a>
                            
                        </li>
                     </ul>
                </div>
            </div>
        </div>

        <div class="main">
     <div class="row">
                <div class="col">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#"><i class="ti-home"></i> Welcome to Dashboard its your space continue helping </a></li>
                        
                    </ol>
                </div>
            </div>