<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>
<?php include 'dash/user-header.php'; ?>

<h1>comming soon..</h1>

	

        <?php include 'dash/footer.php'; ?>
      

<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>