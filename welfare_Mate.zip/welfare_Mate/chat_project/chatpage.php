<?php 
	session_start();
	if(isset($_SESSION['name'])) {
		include "layouts/header2.php"; 
		include "config.php"; 
		
		if (!function_exists('str_openssl_dec')) {
			function str_openssl_dec($str,$iv){
				$key='1234567890vishal%$%^%$$#$#';
				$cipher="AES-128-CTR";
				$options=0;
				$str=openssl_decrypt($str, $cipher, $key, $options, substr($iv, 0, 16));
				return $str;
			}
		}
		
		$res=mysqli_query($conn, "SELECT *, HEX(iv) AS iv FROM chat ORDER BY id DESC");
		if (!$res) {
			die("Query failed: " . mysqli_error($conn));
		}
?>
 

<style>
  h2 {
    color:white;
  }
  label {
    color:white;
  }
  span {
	  color:#673ab7;
	  font-weight:bold;
  }
  .container {
    margin-top: 3%;
    width: 60%;
    background-color: #26262b9e;
    padding-right: 10%;
    padding-left: 10%;
  }
  .btn-primary {
    background-color: #673AB7;
  }
  .display-chat {
    height: 300px;
    background-color: #d69de0;
    margin-bottom: 4%;
    overflow: auto;
    padding: 15px;
  }
  .message {
    background-color: #c616e469;
    color: white;
    border-radius: 5px;
    padding: 5px;
    margin-bottom: 3%;
  }
</style>

<div class="container">
  <center>
    <h2>Welcome <span style="color:#dd7ff3;">
    <?php echo $_SESSION['name']; ?> 
    !</span></h2>
    <label>Join the chat</label>
  </center></br>
  <div class="display-chat">
  
  
  <div class="message">
  <?php

	if(isset($_SESSION['name']))
	{
		include "config.php";
		$key = '1234567890vishal%$%^%$$#$#';
		$stmt = $conn->prepare("SELECT * FROM chat ORDER BY id ASC");
		$stmt->execute();
		$result = $stmt->get_result();
		while($row = $result->fetch_assoc())
		{
			$name = $row['name'];
			$cipher = "AES-128-CTR";
			$iv_hex = $row['iv'];
			$iv = hex2bin($iv_hex);
			$encrypted_msg = $row['message'];
			$decrypted_msg = openssl_decrypt($encrypted_msg, $cipher, $key, 0, $iv);
			?>
			<div class="container">
				<p><b><?php echo htmlspecialchars($name); ?>:</b> <?php echo htmlspecialchars($decrypted_msg); ?></p>
			</div>
      
			<?php
		}
	}
	else
	{
		header('location:index.php');
	}
?>
  </div>
  </div>
  <form class="form-horizontal" method="post" action="sendMessage.php">
    <div class="form-group">
      <div class="col-sm-10">          
        <textarea name="msg" class="form-control" placeholder="Type your message here..."></textarea>
      </div>
	         
      <div class="col-sm-2">
        <button type="submit" class="btn btn-primary">Send</button>
      </div>

    </div>
  </form>
</div>

</body>
</html>

<?php
	}
	else {
		header('location:index.php');
	}
?>
