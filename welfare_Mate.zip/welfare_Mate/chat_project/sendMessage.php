<?php
	session_start();
	if(isset($_SESSION['name']))
	{
		include "config.php";
		if(isset($_POST['msg']) && !empty($_POST['msg']))
		{
			$msg = trim($_POST['msg']);
			$name = $_SESSION['name'];
			$key = '1234567890vishal%$%^%$$#$#';
			$iv = openssl_random_pseudo_bytes(16);
			$encrypted_msg = openssl_encrypt($msg, "AES-128-CTR", $key, 0, $iv);
			$hex_iv = bin2hex($iv);
			$stmt = $conn->prepare("INSERT INTO chat (name, message, iv) VALUES (?, ?, ?)");
			$stmt->bind_param("sss", $name, $encrypted_msg, $hex_iv);
			if ($stmt->execute()) {
				header("Location: chatpage.php");
				exit();
			} else {
				$error = "Failed to insert message into database";
			}
		}
		else{
			$error = "Message cannot be empty";
			}
	}
	else
	{
		header('location:index.php');
	}

	if(isset($error)){
		echo $error;
	}
?>
