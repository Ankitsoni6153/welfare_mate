<!DOCTYPE html>
<html>
<body>
<?php
$conn = mysqli_connect("localhost", "root", "", "welfare");
if($conn === false)
{
echo "ERROR: Could not connect.";
}
$s_no = $_REQUEST['s_no'];
$name = $_REQUEST['name'];

$email_id = $_REQUEST['email_id'];
$subject = $_REQUEST['subject'];


$message = $_REQUEST['message'];
$sql = "INSERT INTO contact VALUES ('$s_no','$name','$email_id','$subject','$message')";
if(mysqli_query($conn, $sql))
{
header("Location: contact.php");
echo" data has been inserted!";

}
else
{
echo "ERROR ";
}
mysqli_close($conn);
?>
</body>
</html>