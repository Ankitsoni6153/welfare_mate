<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {
    include 'dash/header.php'; 
?>

<div class="row">
    <div class="col">
        <div class="card mb-3">
            <div class="card-header">
                <div class="caption uppercase">
                    <i class="ti-briefcase"></i>You have Some messages by donnar..
                </div>
            </div>
            
<h1>Comming soon</h1>

        </div>
    </div>
</div>

<?php 
    include 'dash/footer.php'; 
} else {
    header("Location: index.php");
    exit();
}
?>
